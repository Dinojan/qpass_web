<?php

return array (
  10 => 'Weiblich',
  5 => 'Männlich',
);
