<?php
namespace App\Controllers\Admin;
class EmployeeReportController{

}