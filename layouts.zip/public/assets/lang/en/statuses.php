<?php

return array (
  5 => 'Active',
  10 => 'Inactive',
);
