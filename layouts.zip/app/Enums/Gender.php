<?php
class Gender
{
    const MALE   = 5;
    const FEMALE = 10;
}
