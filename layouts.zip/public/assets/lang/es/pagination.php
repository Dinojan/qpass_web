<?php

return array (
  'previous' => '&laquo; Anterior',
  'next' => 'Siguiente &raquo;',
);

