<?php
class UserApplied
{
    const OWN   = 5;
    const ADMIN = 10;
}
