<?php 
namespace App\Controllers\Admin;

use App\Controllers\BackendController;
class WebNotificationController extends BackendController
{}