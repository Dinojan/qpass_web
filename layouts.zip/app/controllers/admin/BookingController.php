<?php 
namespace App\Controllers\Admin;
class BookingController{

}