<?php

return array (
  1 => 'Pendiente',
  2 => 'Aceptado',
  3 => 'Rechazado',
);