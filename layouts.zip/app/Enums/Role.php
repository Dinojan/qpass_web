<?php
class Role
{
    const ADMIN          = 1;
    const EMPLOYEE       = 2;
    const RECEPTION      = 3;
}
