<?php
function backend_permission($uri, $method) { return true; }
