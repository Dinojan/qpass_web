<?php

return array (
  10 => 'غير نشط',
  5 => 'نشيط',
);
