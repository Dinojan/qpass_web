<?php

return array (
  'reset' => '¡Tu contraseña ha sido restablecida!',
  'sent' => '¡Hemos enviado por correo electrónico tu enlace para restablecer la contraseña!',
  'throttled' => 'Por favor, espera antes de volver a intentarlo.',
  'token' => 'Este token de restablecimiento de contraseña no es válido.',
  'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
);

