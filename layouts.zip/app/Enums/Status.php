<?php
class Status
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}
