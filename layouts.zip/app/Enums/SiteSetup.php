<?php
class SiteSetup
{
    const ENABLE  = 1;
    const DIASBLE = 0;
}
