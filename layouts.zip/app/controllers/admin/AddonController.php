<?php 
namespace App\Controllers\Admin;
class AddonController{

}