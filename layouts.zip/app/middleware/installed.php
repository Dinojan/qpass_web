<?php
function installed($uri, $method) { return true; }