<?php

return array (
  5 => 'Sí',
  10 => 'No',
);

