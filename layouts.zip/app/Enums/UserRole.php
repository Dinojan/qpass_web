<?php
class UserRole
{
    const ADMIN       = 1;
    const EMPLOYEE    = 2;
    const RECEPTION   = 3;
    const SUPER_ADMIN = 4;
}
