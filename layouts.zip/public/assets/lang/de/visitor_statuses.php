<?php

return array (
  1 => 'Besucherbericht',
  2 => 'Accepted',
  3 => 'Ablehnen',
);
