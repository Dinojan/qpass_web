<?php

return array (
  1 => 'Pending',
  2 => 'Accepted',
  3 => 'Reject',
);
