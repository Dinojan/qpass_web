<?php
class Ask
{
    const YES = true;
    const NO  = false;
}
