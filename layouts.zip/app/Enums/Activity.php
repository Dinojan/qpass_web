<?php
class Activity
{
    const ENABLE  = 1;
    const DISABLE = 0;
}
