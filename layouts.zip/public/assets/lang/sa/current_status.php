<?php

return array (
  10 => 'رقم',
  5 => 'نعم',
);
