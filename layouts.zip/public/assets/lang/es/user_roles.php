<?php

return array (
  5 => 'Administrador',
  10 => 'Cliente',
  15 => 'Propietario de tienda',
  20 => 'Repartidor',
);

