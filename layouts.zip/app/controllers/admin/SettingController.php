<?php
namespace App\Controllers\Admin;
use App\Controllers\BackendController;
class SettingController extends BackendController
{}