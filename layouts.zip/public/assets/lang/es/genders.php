<?php

return array (
  5 => 'Masculino',
  10 => 'Femenino',
);

