<?php 
namespace App\Controllers\Admin;
class AttendanceReportController{

}