<?php

return array (
  5 => 'Yes',
  10 => 'No',
);
