<?php

return array (
  10 => 'أنثى',
  5 => 'ذكر',
);
