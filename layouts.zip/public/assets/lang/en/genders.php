<?php

return array (
  5 => 'Male',
  10 => 'Female',
);
