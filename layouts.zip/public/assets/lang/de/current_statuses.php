<?php

return array (
  5 => 'Ja',
  10 => 'Nein',
);
