<?php

return array (
  'next' => 'التالي "',
  'previous' => '" سابق',
);
