<?php

return array (
  'check_out' => 'الدفع',
  'hi' => 'مرحبا',
  'profile' => 'الملف الشخصي',
  'logout' => 'تسجيل خروج',
  'dashboard' => 'لوحة القيادة',
  'enter_Visitor_id' => 'أدخل معرّف الزائر',
);
