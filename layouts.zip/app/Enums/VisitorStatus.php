<?php
class VisitorStatus
{
    const PENDDING = 1;
    const ACCEPT   = 2;
    const REJECT   = 3; 
}
