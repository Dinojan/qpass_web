<?php

return array (
  'next' => 'Nächste "',
  'previous' => '" Vorherige',
);
