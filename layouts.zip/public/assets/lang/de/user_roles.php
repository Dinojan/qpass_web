<?php

return array (
  10 => 'Kunde',
  15 => 'Ladenbesitzer',
  20 => 'Lieferjunge',
  5 => 'Administrator',
);
