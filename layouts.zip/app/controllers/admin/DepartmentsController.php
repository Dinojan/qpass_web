<?php 
namespace App\Controllers\Admin;
class DepartmentsController{

}