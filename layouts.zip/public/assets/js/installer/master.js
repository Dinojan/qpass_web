"use strict";

var x = document.getElementById('error_alert');
var y = document.getElementById('close_alert');
y.onclick = function() {
    x.style.display = "none";
};