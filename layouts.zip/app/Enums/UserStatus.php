<?php
class UserStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}
