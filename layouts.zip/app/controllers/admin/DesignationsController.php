<?php 
namespace App\Controllers\Admin;
class DesignationsController{

}