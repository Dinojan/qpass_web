<?php 
namespace App\Controllers\Admin;
use app\Controllers\BackendController;
class PreRegisterController extends BackendController
{}