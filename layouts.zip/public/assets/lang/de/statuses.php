<?php

return array (
  10 => 'Inaktiv',
  5 => 'Aktiv',
);
