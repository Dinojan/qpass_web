<?php

return array (
  10 => 'Nein',
  5 => 'Ja',
);
