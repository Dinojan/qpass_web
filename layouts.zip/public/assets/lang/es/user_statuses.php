<?php

return array (
  5 => 'Activo',
  10 => 'Inactivo',
);